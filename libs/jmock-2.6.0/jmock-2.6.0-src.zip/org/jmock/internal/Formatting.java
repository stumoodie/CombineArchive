package org.jmock.internal;

public class Formatting {

    public static String times(int i) {
        return i + " " + (i == 1 ? "time" : "times");
    }

}
