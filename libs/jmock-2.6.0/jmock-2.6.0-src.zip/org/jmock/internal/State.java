package org.jmock.internal;

public interface State extends StatePredicate {
    void activate();
}
