package org.jmock.internal;



public interface CaptureControl {
    Object captureExpectationTo(ExpectationCapture capture);
}
