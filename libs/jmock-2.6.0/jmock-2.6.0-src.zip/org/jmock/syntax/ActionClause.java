package org.jmock.syntax;

import org.jmock.api.Action;


public interface ActionClause {
    public abstract void will(Action action);
}
